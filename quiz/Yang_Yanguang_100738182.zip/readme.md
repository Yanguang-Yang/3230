This app is to check users' information and tasks.
For task part, we are allowed to delete or add tasks.

Login Part:
	User needs username and password to login.
	username -> username ; password -> website
	
Only after logging in, Home part and Task part are available.

Home Part:
	Show user's username, Contact info, Address and cat phrase.
	
Task Part:
	Show user's tasks' completion which is also allowed to be edited by user.